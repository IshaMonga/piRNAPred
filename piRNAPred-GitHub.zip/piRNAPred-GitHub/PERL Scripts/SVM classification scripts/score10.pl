#!/usr/bin/perl

## To generate score files having only efficacy value of each sirna seq##

system "cut -f1 -d ' ' test_1.pat >> score_1 ";
system "cut -f1 -d ' ' test_2.pat >> score_2 ";
system "cut -f1 -d ' ' test_3.pat >> score_3 ";
system "cut -f1 -d ' ' test_4.pat >> score_4 ";
system "cut -f1 -d ' ' test_5.pat >> score_5 ";
system "cut -f1 -d ' ' test_6.pat >> score_6 ";
system "cut -f1 -d ' ' test_7.pat >> score_7 ";
system "cut -f1 -d ' ' test_8.pat >> score_8 ";
system "cut -f1 -d ' ' test_9.pat >> score_9 ";
system "cut -f1 -d ' ' test_10.pat >> score_10 ";

